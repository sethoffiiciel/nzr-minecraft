tellraw @p ["",{"text":"Loot Bags ","color":"red"},{"text":"\u2666","bold":true,"color":"red"},{"text":" All trace of the datapack has been removed. ","color":"red"},{"text":"You can now safely remove it from your datapack folder.","color":"gray"}]
clear @a stone_pickaxe[custom_data={rarity:1b,bag:1b}]
clear @a stone_pickaxe[custom_data={rarity:2b,bag:1b}]
clear @a stone_pickaxe[custom_data={rarity:3b,bag:1b}]
scoreboard objectives remove __variable__
scoreboard objectives remove lbags.config


#  - This function was coded by -
#  - Gaming_Reseller -