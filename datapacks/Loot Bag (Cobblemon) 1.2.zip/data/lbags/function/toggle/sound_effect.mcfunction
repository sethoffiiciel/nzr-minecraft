scoreboard players set __if_else__ __variable__ 0
execute if score $lbags.sound_effect __variable__ matches 1 run function lbags:__private__/if_else/7
execute if score __if_else__ __variable__ matches 0 run function lbags:__private__/if_else/8
function lbags:config


#  - This function was coded by -
#  - Gaming_Reseller -