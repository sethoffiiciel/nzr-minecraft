scoreboard players set __if_else__ __variable__ 0
execute if score $lbags.drop_rate __variable__ matches 20 run function lbags:__private__/if_else/9
execute if score __if_else__ __variable__ matches 0 run function lbags:__private__/if_else/12
function lbags:config


#  - This function was coded by -
#  - Gaming_Reseller -