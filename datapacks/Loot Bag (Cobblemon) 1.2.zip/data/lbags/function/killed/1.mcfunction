advancement revoke @s only lbags:killed/1
scoreboard players set __math__.rng.bound __variable__ 0
scoreboard players operation __math__.rng.bound __variable__ += $lbags.drop_rate __variable__
function lbags:__private__/math_random/main
scoreboard players operation $p __variable__ = __math__.rng.result __variable__
scoreboard players add $p __variable__ 1
scoreboard players set __if_else__ __variable__ 0
execute if score $p __variable__ matches ..5 run function lbags:__private__/if_else/0
execute if score __if_else__ __variable__ matches 0 if score $p __variable__ matches ..15 run function lbags:give/1


#  - This function was coded by -
#  - Gaming_Reseller -