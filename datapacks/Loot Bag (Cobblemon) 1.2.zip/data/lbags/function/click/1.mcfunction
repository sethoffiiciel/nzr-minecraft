advancement revoke @s only lbags:click/1
loot give @s loot lbags:reward/1
clear @s cobblemon:sachet[custom_data={lbags:{rarity:1b,bag:1b}}] 1
playsound minecraft:item.bundle.drop_contents


#  - This function was coded by -
#  - Gaming_Reseller -