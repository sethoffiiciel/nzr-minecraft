scoreboard players operation __math__.seed __variable__ *= __math__.rng.a __variable__
scoreboard players operation __math__.seed __variable__ += __math__.rng.c __variable__
scoreboard players operation __math__.rng.result __variable__ = __math__.seed __variable__
scoreboard players operation __math__.tmp __variable__ = __math__.rng.result __variable__
scoreboard players operation __math__.rng.result __variable__ %= __math__.rng.bound __variable__
scoreboard players operation __math__.tmp __variable__ -= __math__.rng.result __variable__
scoreboard players operation __math__.tmp __variable__ += __math__.rng.bound __variable__
execute if score __math__.tmp __variable__ matches ..0 run function lbags:__private__/math_random/main


#  - This function was coded by -
#  - Gaming_Reseller -