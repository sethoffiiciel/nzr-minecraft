data modify storage lbags:lbags sound_effect set value '§a[ON]'
scoreboard players set $lbags.sound_effect __variable__ 1


#  - This function was coded by -
#  - Gaming_Reseller -