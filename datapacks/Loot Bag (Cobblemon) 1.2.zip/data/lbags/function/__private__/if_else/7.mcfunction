scoreboard players set $lbags.sound_effect __variable__ 0
data modify storage lbags:lbags sound_effect set value '§c[OFF]'
scoreboard players set __if_else__ __variable__ 1


#  - This function was coded by -
#  - Gaming_Reseller -