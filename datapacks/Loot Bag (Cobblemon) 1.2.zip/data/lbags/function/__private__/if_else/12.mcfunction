execute if score $lbags.drop_rate __variable__ matches 50 run function lbags:__private__/if_else/10
execute if score __if_else__ __variable__ matches 0 run function lbags:__private__/if_else/11


#  - This function was coded by -
#  - Gaming_Reseller -