scoreboard players set $lbags.drop_rate __variable__ 20
data modify storage lbags:lbags drop_rate set value '§a[Very Common]'


#  - This function was coded by -
#  - Gaming_Reseller -