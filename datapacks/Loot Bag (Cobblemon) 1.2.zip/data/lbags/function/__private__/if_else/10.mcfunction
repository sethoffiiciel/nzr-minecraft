scoreboard players set $lbags.drop_rate __variable__ 200
data modify storage lbags:lbags drop_rate set value '§5[Very Rare]'
scoreboard players set __if_else__ __variable__ 1


#  - This function was coded by -
#  - Gaming_Reseller -