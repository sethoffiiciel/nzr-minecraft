scoreboard players set $lbags.sound_effect __variable__ 1
scoreboard players set $lbags.drop_rate __variable__ 50
data modify storage lbags:lbags sound_effect set value '§a[ON]'
data modify storage lbags:lbags drop_rate set value '§9[Default]'


#  - This function was coded by -
#  - Gaming_Reseller -