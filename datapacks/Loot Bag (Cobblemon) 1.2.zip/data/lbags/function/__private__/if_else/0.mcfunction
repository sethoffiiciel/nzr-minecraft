function lbags:give/1
scoreboard players set __if_else__ __variable__ 1


#  - This function was coded by -
#  - Gaming_Reseller -