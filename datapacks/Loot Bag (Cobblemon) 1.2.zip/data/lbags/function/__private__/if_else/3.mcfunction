execute if score $p __variable__ matches ..10 run function lbags:__private__/if_else/2
execute if score __if_else__ __variable__ matches 0 if score $p __variable__ matches ..18 run function lbags:give/1


#  - This function was coded by -
#  - Gaming_Reseller -