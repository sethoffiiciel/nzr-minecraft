scoreboard players enable @s lbags.config


#  - This function was coded by -
#  - Gaming_Reseller -