function lbags:config
scoreboard players set @s lbags.config 0
scoreboard players enable @s lbags.config


#  - This function was coded by -
#  - Gaming_Reseller -