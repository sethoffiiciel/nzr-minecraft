execute as @a[scores={lbags.config=1..}] at @s run function lbags:__private__/trigger_add/lbags.config


#  - This function was coded by -
#  - Gaming_Reseller -