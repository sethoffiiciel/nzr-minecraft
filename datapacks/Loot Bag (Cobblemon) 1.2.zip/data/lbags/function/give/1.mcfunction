execute if score $lbags.sound_effect __variable__ matches 1.. run playsound minecraft:entity.experience_orb.pickup ambient @p ~ ~ ~ .2 2
give @p cobblemon:sachet[food={saturation:0,can_always_eat:true,nutrition:0,eat_seconds:1000000},!minecraft:tool,!damage,!minecraft:max_damage,!minecraft:attribute_modifiers,minecraft:custom_model_data=930001,custom_data={lbags:{rarity:1b,bag:1b}},max_stack_size=64,custom_name='{"text":"Poke Loot Bag","color":"aqua","italic":false}']
title @p actionbar ["",{"text":"You've found a ","color":"white"},{"text":"Poke Loot Bag","color":"aqua"},{"text":"!","color":"white"}]


#  - This function was coded by -
#  - Gaming_Reseller -