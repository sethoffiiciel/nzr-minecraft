scoreboard objectives add __variable__ dummy
scoreboard objectives add lbags.config trigger
execute unless score __math__.seed __variable__ matches -2147483648..2147483647 run function lbags:__private__/math_random/setup
execute as @a run function lbags:__private__/trigger_add/enable
say loaded
execute unless score $lbags.drop_rate __variable__ matches 1.. unless score $lbags.sound_effect __variable__ matches 1.. run function lbags:__private__/if_else/13


#  - This function was coded by -
#  - Gaming_Reseller -