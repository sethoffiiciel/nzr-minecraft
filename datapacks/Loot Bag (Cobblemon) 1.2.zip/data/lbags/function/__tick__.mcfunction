function lbags:__private__/trigger_add/main


#  - This function was coded by -
#  - Gaming_Reseller -